# Final Project 1

Saahil Claypool

## Opening the project

Open the index.html file in a browser. 

## General Structure

Most of the logic is written in the file draw.js, and in the
shaders that are part of the index.html file. 

The lib files contain dependencies for the project. 


## Implementation Notes

The light source is an odd color to make the specular and diffuse and ambient 
and specular light differences clear. 

The spotlight is centered on the mobile from the perspective of the user. 
The bottom and top shapes are a black plastic and thus less reflective. 
